@extends('layout')

@section('title', 'Cemilan-Page')


@section('content')
    <h1>Halaman Cemilan</h1>
@endsection