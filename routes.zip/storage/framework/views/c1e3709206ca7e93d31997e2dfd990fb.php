<?php $__env->startSection('title', 'Detail-Makanan'); ?>


<?php $__env->startSection('content'); ?>

    <div class="lg:flex ">
         <?php if($menus->img === 'kosong.png'): ?>
         <div class="hidden  lg:block lg:w-1/3 md:block h-screen bg-cover bg-center"
            style="background-image: url('<?php echo e(asset('images/nasgor.jpg')); ?>');">
        </div>
        <div class="lg:hidden w-full h-48 bg-cover bg-center mt-2"
            style="background-image: url('<?php echo e(asset('images/nasgor.jpg')); ?>');">
        </div>
            
        <?php else: ?>
        <div class="hidden  lg:block lg:w-1/3 md:block h-screen bg-cover bg-center"
            style="background-image: url('<?php echo e(asset('storage/'.$menus->img)); ?>');">
        </div>
           <div class="lg:hidden w-full h-48 bg-cover bg-center mt-2"
                style="background-image: url('<?php echo e(asset('storage/'.$menus->img)); ?>');">
            </div>
        <?php endif; ?>
        <!-- Kalimat di sebelah kanan -->
        <div class="lg:w-2/3  p-10">
            <h1 class="text-4xl font-bold mb-4"><?php echo e($menus->title); ?></h1>
            <div class="w-full ">
                <?php $__currentLoopData = $rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class=" bg-white p-4 rounded-lg shadow mb-3">
                        <h3 class="text-xl font-semibold">Rating: <?php echo e($items->rating); ?>/5</h3>
                        <p class="text-gray-600">Reviewer: <?php echo e($items->user->name); ?></p>
                        <p class="text-gray-600">Date:
                            <?php echo e(\Carbon\Carbon::parse($items->created_at)->isoFormat('D MMMM Y')); ?></p>
                        <p class="mt-2">Comment: <?php echo e($items->review); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="flex flex-col mt-5 p-10">

                <?php echo e($rates->links('pagination::tailwind')); ?>

            </div>
        </div>

       

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SEKTE ANI\clone\resep-kosan\resources\views/makanan/rating.blade.php ENDPATH**/ ?>