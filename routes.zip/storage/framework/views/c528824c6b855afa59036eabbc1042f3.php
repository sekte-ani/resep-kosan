<?php $__env->startSection('content'); ?>

<section class="row">
    <div class="d-flex gap-3">
        <div class="col-6 col-lg-6 col-md-6">
            <div class="card card-stat">
                <div class="card-body px-4 py-4-5">
                    
                        <h3 class="ps-2">Total User</h3>
                        <div class="d-flex align-items-start flex-column p-2 mb-2">
                            <p class="fs-1 p-3 rounded fw-bolder text-success"><?php echo e($totalUser); ?></p>
                        </div>
                    
                </div>
            </div>
        </div>
        <div class="col-6 col-lg-6 col-md-6">
            <div class="card card-stat">
                <div class="card-body px-4 py-4-5">
                    
                        <h3 class="ps-2">Total Menu</h3>
                        <div class="d-flex align-items-start flex-column p-2 mb-2">
                            <p class="fs-1 p-3 rounded fw-bolder text-success"><?php echo e($totalMenu); ?></p>
                        </div>
                    
                </div>
            </div>
        </div>
        
    </div>
</section>

<section class="row">
	<div class="col card px-3 py-3">

		<div class="my-3 p-3 rounded">
			<div class="mb-3">
				<h2>List User</h2>
			</div>
			
			
			<!-- Table untuk memanggil data dari database -->
			<table class="table">
				<thead>	
					<tr>
						<th class="col-md-2">No</th>
						<th class="col-md-2">Nama</th>
						<th class="col-md-2">Email</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($loop->iteration); ?></td>
							<td><?php echo e($item->name); ?></td>
							<td><?php echo e($item->email); ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			<?php echo e($users->withQueryString()->links()); ?>

		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('modal'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.main', ['title' => 'Dashboard', 'page_heading' => 'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SEKTE ANI\clone\resep-kosan\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>