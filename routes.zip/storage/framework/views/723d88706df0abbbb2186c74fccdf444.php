<?php $__env->startSection('title', 'Resep-Makanan'); ?>


<?php $__env->startSection('content'); ?>
<div class="mx-12 mt-10 md:flex flex-wrap  sm:flex-1">
    
    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700 mb-4 md:w-[300px] mx-5">
             <a href="/makanan/<?php echo e($items->slug); ?>">
                <?php if($items->img == 'kosong.png'): ?>
                    <img src="<?php echo e(asset('images/drink5.jpg')); ?>" alt="makanan" class="rounded-t-lg">
                    
                <?php else: ?>
                    <img src="<?php echo e(asset('storage/'. $items->img)); ?>" alt="makanan" class="rounded-t-lg">
                <?php endif; ?>
                <div class="p-5">
                    <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white"><?php echo e($items->title); ?></h5>
                    
                    <p class="mb-3 font-normal text-gray-700 dark:text-gray-400"><?php echo e($items->slug); ?>.</p>
                </div>
             </a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SEKTE ANI\clone\resep-kosan\resources\views/dashboard/search.blade.php ENDPATH**/ ?>