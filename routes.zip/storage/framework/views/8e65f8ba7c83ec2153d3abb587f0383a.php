<?php if(request()->session()->get('success')): ?>
<script>
    Toastify({
        text: "<?php echo e(session('success')); ?>",
        duration: 3000,
        close: true,
        backgroundColor: "#4fbe87",
    }).showToast();
</script>
<?php endif; ?>

<?php if(request()->session()->get('warning')): ?>
<script>
    Toastify({
        text: "<?php echo e(session('warning')); ?>",
        duration: 3000,
        close: true,
        backgroundColor: "#eaca4a",
    }).showToast();
</script>
<?php endif; ?>

<?php if(count($errors) !== 0): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<script>
    Toastify({
        text: "<?php echo e($message); ?>",
        duration: 3000,
        close: true,
        backgroundColor: "#f3616d",
    }).showToast();
</script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\SEKTE ANI\clone\resep-kosan\resources\views/admin/utilities/toastify-flash-message.blade.php ENDPATH**/ ?>