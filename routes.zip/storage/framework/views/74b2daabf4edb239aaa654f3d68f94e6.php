

<?php $__env->startSection('title', 'Makanan-Page'); ?>


<?php $__env->startSection('content'); ?>

    <?php if(session('error')): ?>
        <h1><?php echo e(session('error')); ?></h1>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SEKTE ANI\clone\resep-kosan\resources\views/error.blade.php ENDPATH**/ ?>