
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo e(config('app.name')); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/pages/auth.css')); ?>">
</head>

<body>
    <div id="auth">
        <?php echo $__env->yieldContent('content'); ?>

    </div>
</body>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>

</html><?php /**PATH C:\xampp\htdocs\SEKTE ANI\clone\resep-kosan\resources\views/admin/layouts/auth/main.blade.php ENDPATH**/ ?>