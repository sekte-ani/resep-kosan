<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.utilities.alert-flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="row">
        <div class="col card px-3 py-3">
            <div class="my-3 p-3 rounded">

                <!-- Navigation -->
                <div class="pb-3 d-flex justify-content-start">
                    <a href="/dashboard-menu" class="btn btn-secondary">Kembali</a>
                </div>

                <!-- Menu Details -->
                <div>
                    <h3>Nama Makanan</h3>
                    <p><?php echo e($menu->title); ?></p>
                    
                    <h3>Kategori</h3>
                    <p><?php echo e($menu->category->name); ?></p>
                    
                    <h3>Gambar Makanan</h3>
                    <img src="<?php echo e(asset("storage/".$menu->img)); ?>" alt="<?php echo e($menu->title); ?>" class="img-fluid mb-3"
                        style="max-height: 200px;">

                    <h3>Deskripsi</h3>
                    <p><?php echo $menu->desc; ?></p>

                    <!-- Ratings -->
                    <?php $__currentLoopData = $rating; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card bg-primary mt-3">
                            <div class="card-body">
                                <h4 class="card-title text-white"><?php echo e($item->user->name); ?></h4>
                                <h6 class="card-title text-white"><?php echo e($item->rating); ?>/5</h6>
                                <p class="card-text text-white"><?php echo e($item->review); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Pagination for Ratings -->
                    <?php echo e($rating->withQueryString()->links()); ?>

                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modal'); ?>
    <?php echo $__env->make('admin.menu.modal.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.main', ['title' => 'Detail Menu', 'page_heading' => 'Detail Menu'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SEKTE ANI\clone\resep-kosan\resources\views/admin/menu/modal/detail.blade.php ENDPATH**/ ?>