<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body class="bg-gray-50">
    
    <header>


        <nav class="bg-[#495E57] border-gray-200">
            <div class="xl:max-screen-3xl md:max-w-screen-2xl  flex flex-wrap items-center justify-between mx-5 p-4">
                <a href="#" class="flex items-center space-x-3 rtl:space-x-reverse">

                    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo Perusahaan" class="w-12 object-cover">

                    <form action="/search" method="GET">

                        <div class="relative ">
                            <input type="text" id="search-navbar"
                                class="block w-fullp-2 pl-10 text-sm text-white border rounded-lg bg-[#607E74] focus:ring-gray-400 focus:border-gray-400 w-[180px] handphone:w-[210px] md:w-[500px]    "
                                placeholder="Search..." name="search">
                            <svg class="absolute w-4 h-4 text-[#F4CE14]  top-3 left-3" aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z" />
                            </svg>
                    </form>
            </div>
            </a>

            <button data-collapse-toggle="navbar-default" type="button"
                class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600"
                aria-controls="navbar-default" aria-expanded="false">
                <span class="sr-only">Open main menu</span>
                <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                    viewBox="0 0 17 14">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M1 1h15M1 7h15M1 13h15" />
                </svg>
            </button>

            <div class="hidden w-full md:block md:w-auto" id="navbar-default">
                <ul
                    class="flex list-none flex-col p-4 md:p-0 mt-4 font-medium border border-gray-100 rounded-lg md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0">
                    <li>
                        <a href="<?php echo e(route('dashboard.index')); ?>"
                            class="<?php echo e(request()->routeIs('') ? 'active' : ''); ?> block py-2 px-3  text-white rounded hover:bg-gray-100  hover:text-[#D0AD06] hover:underline md:hover:bg-transparent md:hover:text-[#D0AD06]  md:p-0"
                            aria-current="page">Beranda</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('makanan.index')); ?>"
                            class="<?php echo e(request()->routeIs('makanan*') ? 'active' : ''); ?> block py-2 px-3  text-white rounded hover:bg-gray-100 hover:text-[#D0AD06] hover:underline md:hover:bg-transparent md:hover:text-[#D0AD06] md:p-0  ">Makanan</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('minuman.index')); ?>"
                            class="<?php echo e(request()->routeIs('minuman*') ? 'active' : ''); ?> block py-2 px-3  text-white rounded hover:bg-gray-100  hover:text-[#D0AD06] hover:underline md:hover:bg-transparent md:hover:text-[#D0AD06]  md:p-0 ">Minuman</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('cemilan.index')); ?>"
                            class="<?php echo e(request()->routeIs('cemilan*') ? 'active' : ''); ?> block py-2 px-3  text-white rounded  hover:underline hover:text-[#D0AD06] hover:bg-gray-100 md:hover:bg-transparent md:hover:text-[#D0AD06] md:p-0 ">Cemilan</a>
                    </li>


                    <?php if(Auth::user() === null): ?>
                         <li>
                            <a href="<?php echo e(route('login')); ?>"
                                class="block py-2 px-3 text-white rounded hover:underline hover:text-[#D0AD06] hover:bg-gray-100 md:hover:bg-transparent md:hover:text-[#D0AD06] md:p-0">Login</a>
                        </li>
                    <?php elseif(Auth::user()->role === 'admin'): ?>
                        <li>
                            <a href="#"
                                class="block py-2 px-3 text-white rounded hover:underline hover:text-[#D0AD06] hover:bg-gray-100 md:hover:bg-transparent md:hover:text-[#D0AD06] md:p-0">Login</a>
                        </li>
                    <?php else: ?>
                        <li>
                            <form action="/logout" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    class="block py-2 px-3 text-white rounded hover:underline hover:text-[#D0AD06] hover:bg-gray-100 md:hover:bg-transparent md:hover:text-[#D0AD06] md:p-0">Logout</button>
                            </form>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
            </div>
        </nav>


    </header>
    

    
    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    

    
    <footer></footer>

    
    

    <script>
        document.getElementById('openModal').addEventListener('click', function() {
            document.getElementById('modal').classList.remove('hidden');
        });

        document.getElementById('closeModal').addEventListener('click', function() {
            document.getElementById('modal').classList.add('hidden');
        });
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\SEKTE ANI\clone\resep-kosan\resources\views/layout.blade.php ENDPATH**/ ?>