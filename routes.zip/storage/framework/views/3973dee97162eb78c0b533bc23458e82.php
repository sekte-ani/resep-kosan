<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.utilities.alert-flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="row">
	<div class="col card px-3 py-3">

	<div class="my-3 p-3 rounded">

		
		<!-- TOMBOL TAMBAH DATA -->
		<div class="pb-3 d-flex justify-content-end">
			<!-- Button trigger modal -->
			
			<a href='/dashboard-menu/create' class="btn btn-success">+ Tambah Data</a>
			
		</div>
		<!-- Table untuk memanggil data dari database -->
		<table class="table table-hover">
			<thead>
				<tr>
					
					<th class="col-md-1">No</th>
					<th class="col-md-2">Nama Menu</th>
					<th class="col-md-2">Kategori</th>
					<th class="col-md-3">Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $allMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($loop -> iteration); ?></td>
					<td><?php echo e($item -> title); ?></td>
					<td><?php echo e($item -> category->name); ?></td>
					<td>
						
						<a href='<?php echo e(url('dashboard-menu/detail/'.$item->slug)); ?>' class="btn btn-primary btn-sm">Detail</a>
						
						
						<a href='<?php echo e(url('dashboard-menu/edit/'.$item->slug)); ?>' class="btn btn-warning btn-sm">Edit</a>
						
						<form onsubmit="return confirm('Apakah anda yakin ingin menghapus data?')" class="d-inline" action="/dashboard-menu/delete/<?php echo e($item->slug); ?>" method="post">
							<?php echo csrf_field(); ?>
							<?php echo method_field('delete'); ?>
							<button type="submit" name="submit" class="btn btn-danger btn-sm">Delete</button>
						</form>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		
		<?php echo e($allMenu->withQueryString()->links()); ?>

			
		
		
			
		
  </div>
</div>

</section>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('modal'); ?>
<?php echo $__env->make('admin.menu.modal.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopPush(); ?>



<?php echo $__env->make('admin.layouts.main', ['title' => 'Menu', 'page_heading' => 'List Semua Menu'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SEKTE ANI\clone\resep-kosan\resources\views/admin/menu/index.blade.php ENDPATH**/ ?>